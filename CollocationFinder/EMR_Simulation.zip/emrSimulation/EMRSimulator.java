package emrSimulation;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;

import java.io.*;
import java.util.*;

public class EMRSimulator {

    /**
     *                  READ ME
     *
     *      This is a simulation of the EMR process.
     *      The main function is the entry point of the simulation.
     *      The main function is responsible for running the entire EMR process.
     *
     *      The main differences between the simulation and the actual EMR process are:
     *      1. The input is read from a file instead of S3
     *      2. The output is printed to the console instead of being written to S3
     *      3. String is used instead of Text,
     *         Long is used instead of LongWritable,
     *         Double is used instead of DoubleWritable etc...
     *      4. Comparator is used instead of WritableComparator
     *
     *      an example is given in the main function.
     *
     */

    public static void main(String[] args) {
        System.out.println("EMR Simulator");
        String inputPath = args[0];
        try{
            String corpus = readInputFile(inputPath);

            // Step 1
            Configuration conf = new Configuration();
            conf.set("stopWordsFile", "heb_stop_words.txt");
            conf.set("corpusPercentage", "1.0");
            conf.set("language", "hebrew");
            Map<Long,String> input = makeMapperInput(corpus);
            Step1Mapper step1Mapper = new Step1Mapper(input,conf ,new Step1Comparator());
            step1Mapper.run();
            Step1Reducer step1Reducer = new Step1Reducer(step1Mapper.getOutput(),conf);
            step1Reducer.run();
            String step1Output = step1Reducer.getOutput();

            // Step 2
            input = makeMapperInput(step1Output);
            conf = new Configuration();
            Step2Mapper step2Mapper = new Step2Mapper(input,conf, new Step2Comparator());
            step2Mapper.run();
            Step2Reducer step2Reducer = new Step2Reducer(step2Mapper.getOutput(),conf);
            step2Reducer.run();
            String step2Output = step2Reducer.getOutput();

            // Step 3
            input = makeMapperInput(step2Output);
            conf = new Configuration();
            conf.set("minPmi", "0.5");
            conf.set("relMinPmi", "0.2");
            Step3Mapper step3Mapper = new Step3Mapper(input,conf, new Step3Comparator());
            step3Mapper.run();
            Step3Reducer step3Reducer = new Step3Reducer(step3Mapper.getOutput(),conf);
            step3Reducer.run();
            String step3Output = step3Reducer.getOutput();

            // Print the output
            System.out.println(step3Output);

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public static class Step1Mapper extends SimulatedMapper<Long,String,String,Long> {
        public Step1Mapper(Map<Long, String> _input, Configuration conf) {
            super(_input,conf);
        }

        public Step1Mapper(Map<Long, String> _input, Configuration _conf, Comparator<String> comparator) {
            super(_input, _conf, comparator);
        }

        @Override
        protected void map(Long key, String value, Context context) throws IOException, InterruptedException {

        }

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {

        }

    }

    public static class Step1Comparator implements Comparator<String> {

        @Override
        public int compare(String a, String b) {
            return a.compareTo(b);
        }
    }

    public static class Step1Reducer extends SimulatedReducer<String,Long,String,String>{

        public Step1Reducer(Map<String, Iterable<Long>> _input, Configuration conf) {
            super(_input,conf);
        }

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {

        }

        @Override
        protected void reduce(String key, Iterable<Long> values, Context context) throws IOException, InterruptedException {

        }

    }

    public static class Step2Mapper extends SimulatedMapper<Long,String,String,String>{
        public Step2Mapper(Map<Long, String> _input, Configuration _conf) {
            super(_input, _conf);
        }

        public Step2Mapper(Map<Long, String> _input, Configuration _conf, Comparator<String> comparator) {
            super(_input, _conf, comparator);
        }

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {

        }

        @Override
        protected void map(Long key, String value, Context context) throws IOException, InterruptedException {

        }

    }

    public static class Step2Comparator implements Comparator<String> {

        @Override
        public int compare(String a, String b) {
            return a.compareTo(b);
        }
    }

    public static class Step2Reducer extends SimulatedReducer<String,String,String,Double>{
        public Step2Reducer(Map<String, Iterable<String>> _input, Configuration _conf) {
            super(_input, _conf);
        }

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {

        }

        @Override
        protected void reduce(String key, Iterable<String> values, Context context) throws IOException, InterruptedException {

        }

    }

    public static class Step3Mapper extends SimulatedMapper<Long,String,String,String> {
        public Step3Mapper(Map<Long, String> _input, Configuration _conf) {
            super(_input, _conf);
        }

        public Step3Mapper(Map<Long, String> _input, Configuration _conf, Comparator<String> comparator) {
            super(_input, _conf, comparator);
        }

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {

        }

        @Override
        protected void map(Long key, String value, Context context) throws IOException, InterruptedException {

        }
    }

    public static class Step3Comparator implements Comparator<String> {

        @Override
        public int compare(String a, String b) {
            return a.compareTo(b);
        }
    }

    public static class Step3Reducer extends SimulatedReducer<String,String,String,String> {
        public Step3Reducer(Map<String, Iterable<String>> _input, Configuration _conf) {
            super(_input, _conf);
        }

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {

        }

        @Override
        protected void reduce(String key, Iterable<String> values, Context context) throws IOException, InterruptedException {

        }
    }

    private static Map<Long,String> makeMapperInput(String input) {
        Map<Long,String> mapperInput = new TreeMap<>();
        String[] lines = input.split("\n");

        long index = 0;
        for(String line : lines){
            mapperInput.put(index++,line);
        }
        return mapperInput;
    }

    private static String readInputFile(String inputPath) throws IOException {
        StringBuilder output = new StringBuilder();
        try(BufferedReader reader = new BufferedReader(new FileReader(inputPath))){
            String line;
            while((line = reader.readLine()) != null){
                output.append(line).append("\n");
            }
        }
        return output.toString();
    }

}
